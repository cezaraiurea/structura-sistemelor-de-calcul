# 2025-01-08T12:31:23.884590400
import vitis

client = vitis.create_client()
client.set_workspace(path="C:/Users/Admin/Desktop/ANUL3_SEM1/SSC_Proiect/platforma_vitis")

platform = client.get_component(name="platforma")
status = platform.build()

vitis.dispose()

