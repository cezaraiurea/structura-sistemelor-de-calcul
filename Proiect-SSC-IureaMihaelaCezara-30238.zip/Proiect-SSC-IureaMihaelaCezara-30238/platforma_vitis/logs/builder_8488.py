# 2024-12-11T13:12:00.181560500
import vitis

client = vitis.create_client()
client.set_workspace(path="C:/Users/Admin/Desktop/ANUL3_SEM1/SSC_Proiect/platforma_vitis")

platform = client.create_platform_component(name = "platforma",hw_design = "C:/Users/Admin/Desktop/ANUL3_SEM1/SSC_Proiect/keypad/design_1_wrapper.xsa",os = "standalone",cpu = "ps7_cortexa9_0",domain_name = "standalone_ps7_cortexa9_0")

platform = client.get_component(name="platforma")
status = platform.build()

comp = client.create_app_component(name="aplicatie",platform = "C:/Users/Admin/Desktop/ANUL3_SEM1/SSC_Proiect/platforma_vitis/platforma/export/platforma/platforma.xpfm",domain = "standalone_ps7_cortexa9_0",template = "hello_world")

status = platform.build()

comp = client.get_component(name="aplicatie")
comp.build()

status = platform.build()

comp.build()

status = platform.build()

comp.build()

status = platform.build()

comp.build()

vitis.dispose()

