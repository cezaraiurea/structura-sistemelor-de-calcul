# 2024-12-18T14:28:43.100756400
import vitis

client = vitis.create_client()
client.set_workspace(path="C:/Users/Admin/Desktop/ANUL3_SEM1/SSC_Proiect/platforma_vitis")

platform = client.get_component(name="platforma")
status = platform.build()

status = platform.build()

status = platform.build()

comp = client.get_component(name="aplicatie")
comp.build()

vitis.dispose()

