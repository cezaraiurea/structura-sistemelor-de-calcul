# 2025-01-03T02:12:19.430662700
import vitis

client = vitis.create_client()
client.set_workspace(path="C:/Users/Admin/Desktop/ANUL3_SEM1/SSC_Proiect/platforma_vitis")

vitis.dispose()

