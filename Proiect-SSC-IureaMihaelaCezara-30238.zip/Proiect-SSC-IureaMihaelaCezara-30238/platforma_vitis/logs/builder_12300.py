# 2024-12-18T14:54:31.203310900
import vitis

client = vitis.create_client()
client.set_workspace(path="C:/Users/Admin/Desktop/ANUL3_SEM1/SSC_Proiect/platforma_vitis")

platform = client.get_component(name="platforma")
status = platform.build()

comp = client.get_component(name="aplicatie")
comp.build()

status = platform.build()

comp.build()

status = platform.build()

comp.build()

status = platform.build()

comp.build()

status = platform.build()

comp.build()

status = platform.build()

comp.build()

status = platform.build()

comp.build()

status = platform.build()

comp.build()

status = platform.build()

comp.build()

status = platform.build()

comp.build()

status = platform.build()

comp.build()

status = platform.build()

comp.build()

status = platform.build()

comp.build()

status = platform.build()

comp.build()

status = platform.build()

comp.build()

status = platform.build()

comp.build()

