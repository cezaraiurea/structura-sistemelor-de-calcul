# 2024-12-11T13:45:48.929508600
import vitis

client = vitis.create_client()
client.set_workspace(path="C:/Users/Admin/Desktop/ANUL3_SEM1/SSC_Proiect/platforma_vitis")

vitis.dispose()

